// import Space from "./Space";
import TextureSphere from "./TextureSphere";
// import ToggleApp from "./ToggleApp";
export default function App() {
  return (
    <div className="App">
      <TextureSphere />
    </div>
  );
}
